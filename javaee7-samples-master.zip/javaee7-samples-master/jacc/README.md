# Java EE 7 Samples: JACC - Java Authorization Contract for Containers #

The [JSR 115](https://jcp.org/en/jsr/detail?id=115) seeks to define a contract between containers and authorization service providers that will result in the implementation of providers for use by containers. 

## Samples ##

 - contexts

## How to run

More information on how to run can be found at: <https://github.com/javaee-samples/javaee7-samples#how-to-run->


