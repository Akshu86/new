# Java EE 7 Samples: EL 3.0 #

The [JSR 341](https://jcp.org/en/jsr/detail?id=341) is an update to Expression Language 2.2, currently part of JSR 245, JavaServer Page (JSP) 2.2. 

## Samples ##

 - standalone

## How to run

More information on how to run can be found at: <https://github.com/javaee-samples/javaee7-samples#how-to-run->


