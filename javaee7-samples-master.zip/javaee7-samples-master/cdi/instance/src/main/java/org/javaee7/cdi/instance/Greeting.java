package org.javaee7.cdi.instance;

/**
 * @author Arun Gupta
 * @author Radim Hanus
 */
public interface Greeting {
	String greet(String name);
}
