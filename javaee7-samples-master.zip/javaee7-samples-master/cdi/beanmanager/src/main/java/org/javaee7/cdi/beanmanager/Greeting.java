package org.javaee7.cdi.beanmanager;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}
