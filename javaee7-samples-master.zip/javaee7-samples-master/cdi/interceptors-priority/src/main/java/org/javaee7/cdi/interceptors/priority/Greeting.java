package org.javaee7.cdi.interceptors.priority;

/**
 * @author Radim Hanus
 */
public interface Greeting {
    public String getGreet();

    public void setGreet(String name);
}
