package org.javaee7.cdi.events;

/**
 * @author Radim Hanus
 */
public interface EventReceiver {
    String getGreet();
}
